import React, { createContext, useContext, useState, ReactNode } from 'react';
import { VideoData, ProcessingStatus } from '../types';

interface AppContextType {
  videos: VideoData[];
  addVideo: (video: VideoData) => void;
  updateVideoStatus: (id: string, status: ProcessingStatus) => void;
  updateVideoProgress: (id: string, progress: number) => void;
  deleteVideo: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider = ({ children }: AppProviderProps) => {
  const [videos, setVideos] = useState<VideoData[]>([]);

  const addVideo = (video: VideoData) => {
    setVideos((prev) => [...prev, video]);
  };

  const updateVideoStatus = (id: string, status: ProcessingStatus) => {
    setVideos((prev) =>
      prev.map((video) => (video.id === id ? { ...video, status } : video))
    );
  };

  const updateVideoProgress = (id: string, progress: number) => {
    setVideos((prev) =>
      prev.map((video) => (video.id === id ? { ...video, progress } : video))
    );
  };

  const deleteVideo = (id: string) => {
    setVideos((prev) => prev.filter((video) => video.id !== id));
  };

  const value = {
    videos,
    addVideo,
    updateVideoStatus,
    updateVideoProgress,
    deleteVideo,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
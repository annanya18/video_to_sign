export type ProcessingStatus = 
  | 'uploading'
  | 'transcribing'
  | 'processing'
  | 'generating'
  | 'syncing'
  | 'completed'
  | 'failed';

export interface VideoData {
  id: string;
  title: string;
  originalUrl: string;
  convertedUrl?: string;
  thumbnailUrl?: string;
  duration: number;
  uploadDate: Date;
  progress: number;
  status: ProcessingStatus;
  transcription?: string;
}

export interface AvatarSettings {
  model: 'default' | 'realistic' | 'cartoon';
  gender: 'male' | 'female' | 'neutral';
  signLanguage: 'asl' | 'bsl' | 'auslan';
  speed: number;
}

export interface VideoUploadProps {
  onUploadComplete: (videoData: VideoData) => void;
}

export interface VideoPlayerProps {
  originalUrl: string;
  convertedUrl?: string;
  showComparison?: boolean;
}

export interface ProcessingStepProps {
  status: ProcessingStatus;
  progress: number;
}

export interface VideoCardProps {
  video: VideoData;
  onDelete?: (id: string) => void;
}
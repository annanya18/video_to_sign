import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, MessageSquare, Video, Lightbulb, PanelTop } from 'lucide-react';

const Home = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-900 to-primary-700 text-white">
        <div className="container mx-auto px-4 py-20 md:py-32">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Making Video Content Accessible Through Sign Language
            </h1>
            <p className="text-xl md:text-2xl mb-10 text-gray-200">
              Convert spoken language videos to sign language with our AI-powered platform
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link 
                to="/convert" 
                className="px-8 py-4 bg-accent-500 hover:bg-accent-600 rounded-lg font-medium transition-colors duration-300 flex items-center justify-center"
              >
                Start Converting <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
              <Link 
                to="/about" 
                className="px-8 py-4 bg-transparent border border-white hover:bg-white/10 rounded-lg font-medium transition-colors duration-300 flex items-center justify-center"
              >
                Learn More
              </Link>
            </div>
          </div>
        </div>
        <div className="h-20 bg-white" style={{ clipPath: 'polygon(0 0, 100% 100%, 100% 0)' }}></div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">How It Works</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our innovative technology transforms spoken content into accessible sign language videos in four simple steps
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <MessageSquare className="w-10 h-10 text-primary-700" />,
                title: 'Speech to Text',
                description: 'Advanced Whisper ASR technology accurately transcribes spoken content from your video'
              },
              {
                icon: <Lightbulb className="w-10 h-10 text-primary-700" />,
                title: 'NLP Enhancement',
                description: 'Natural Language Processing refines the transcript for optimal sign language conversion'
              },
              {
                icon: <PanelTop className="w-10 h-10 text-primary-700" />,
                title: '3D Avatar Generation',
                description: 'MediaPipe and SignGAN create realistic signing avatars that convey the message clearly'
              },
              {
                icon: <Video className="w-10 h-10 text-primary-700" />,
                title: 'Lip Synchronization',
                description: 'Wav2Lip technology ensures perfect lip synchronization for natural communication'
              }
            ].map((step, index) => (
              <div 
                key={index} 
                className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
              >
                <div className="bg-gray-100 p-4 rounded-full inline-block mb-6">
                  {step.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3 text-gray-900">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">Key Features</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our platform combines cutting-edge AI technologies to deliver high-quality sign language videos
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Customizable Avatars',
                description: 'Choose from different avatar styles, adjust signing speed, and select preferred sign language variants'
              },
              {
                title: 'Side-by-Side View',
                description: 'Compare original and sign language videos simultaneously for complete context and understanding'
              },
              {
                title: 'High Accuracy',
                description: 'State-of-the-art AI models ensure accurate translation and natural signing movements'
              },
              {
                title: 'Batch Processing',
                description: 'Convert multiple videos simultaneously with our efficient processing pipeline'
              },
              {
                title: 'Easy Sharing',
                description: 'Download and share your converted videos across platforms with simple integration options'
              },
              {
                title: 'Video Library',
                description: 'Access all your converted videos in one place with organized storage and search capabilities'
              }
            ].map((feature, index) => (
              <div 
                key={index} 
                className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
              >
                <h3 className="text-xl font-semibold mb-3 text-gray-900">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-accent-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Make Your Videos Accessible?</h2>
          <p className="text-xl mb-10 max-w-2xl mx-auto">
            Join thousands of content creators who are breaking barriers and reaching wider audiences
          </p>
          <Link 
            to="/convert" 
            className="px-8 py-4 bg-white text-accent-600 hover:bg-gray-100 rounded-lg font-medium transition-colors duration-300 inline-block"
          >
            Start Converting Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
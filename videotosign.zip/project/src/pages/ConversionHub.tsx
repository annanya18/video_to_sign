import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { AvatarSettings } from '../types';
import VideoUploader from '../components/conversion/VideoUploader';
import ProcessingPipeline from '../components/conversion/ProcessingPipeline';
import AvatarCustomizer from '../components/conversion/AvatarCustomizer';
import ConversionComplete from '../components/conversion/ConversionComplete';
import { ChevronRight } from 'lucide-react';

const ConversionHub = () => {
  const { videos, addVideo, updateVideoStatus, updateVideoProgress } = useAppContext();
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [step, setStep] = useState<number>(1);
  const [avatarSettings, setAvatarSettings] = useState<AvatarSettings>({
    model: 'default',
    gender: 'neutral',
    signLanguage: 'asl',
    speed: 1,
  });

  const activeVideo = activeVideoId ? videos.find(v => v.id === activeVideoId) : null;

  const handleVideoUpload = (videoData: any) => {
    addVideo(videoData);
    setActiveVideoId(videoData.id);
    setStep(2);
    
    // Simulate transcription process
    simulateTranscription(videoData.id);
  };

  const simulateTranscription = (videoId: string) => {
    updateVideoStatus(videoId, 'transcribing');
    
    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      updateVideoProgress(videoId, progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        updateVideoStatus(videoId, 'processing');
        setTimeout(() => {
          setStep(3);
        }, 1000);
      }
    }, 500);
  };

  const handleAvatarSettingsChange = (settings: AvatarSettings) => {
    setAvatarSettings(settings);
  };

  const handleStartGeneration = () => {
    if (!activeVideoId) return;
    
    setStep(4);
    updateVideoStatus(activeVideoId, 'generating');
    
    // Simulate avatar generation and lip syncing
    let progress = 0;
    const interval = setInterval(() => {
      progress += 2;
      updateVideoProgress(activeVideoId, progress);
      
      if (progress >= 50) {
        updateVideoStatus(activeVideoId, 'syncing');
      }
      
      if (progress >= 100) {
        clearInterval(interval);
        updateVideoStatus(activeVideoId, 'completed');
        
        // Update video with a simulated converted URL
        const updatedVideo = videos.find(v => v.id === activeVideoId);
        if (updatedVideo) {
          updatedVideo.convertedUrl = updatedVideo.originalUrl;
        }
      }
    }, 300);
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return <VideoUploader onUploadComplete={handleVideoUpload} />;
      case 2:
        return activeVideo && <ProcessingPipeline video={activeVideo} />;
      case 3:
        return (
          <AvatarCustomizer 
            settings={avatarSettings} 
            onSettingsChange={handleAvatarSettingsChange} 
            onStartGeneration={handleStartGeneration}
          />
        );
      case 4:
        return activeVideo && <ConversionComplete video={activeVideo} />;
      default:
        return <VideoUploader onUploadComplete={handleVideoUpload} />;
    }
  };

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-900">Video Conversion Hub</h1>
        
        {/* Progress Steps */}
        <div className="mb-12">
          <div className="flex items-center">
            {[
              { number: 1, title: 'Upload Video' },
              { number: 2, title: 'Transcribe Content' },
              { number: 3, title: 'Customize Avatar' },
              { number: 4, title: 'Generate Sign Video' }
            ].map((item, index) => (
              <React.Fragment key={item.number}>
                <div className="flex flex-col items-center">
                  <div 
                    className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                      step >= item.number 
                        ? 'bg-primary-700 text-white' 
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {step > item.number ? '✓' : item.number}
                  </div>
                  <span className={`text-sm ${step >= item.number ? 'text-primary-700 font-medium' : 'text-gray-600'}`}>
                    {item.title}
                  </span>
                </div>
                {index < 3 && (
                  <div className="flex-1 h-1 mx-4 bg-gray-200">
                    <div 
                      className="h-full bg-primary-700 transition-all duration-500" 
                      style={{ width: step > item.number ? '100%' : '0%' }}
                    ></div>
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
        
        {/* Step Content */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          {renderStepContent()}
        </div>
      </div>
    </div>
  );
};

export default ConversionHub;
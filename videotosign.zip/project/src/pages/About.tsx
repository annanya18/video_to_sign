import React from 'react';
import { Link } from 'react-router-dom';
import { BarChart, BookOpen, GitMerge, HeartHandshake, Globe, ArrowRight } from 'lucide-react';

const About = () => {
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">About SignSync</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="md:col-span-2">
            <p className="text-lg text-gray-700 mb-6">
              SignSync is an AI-powered tool that makes video content accessible to the deaf and hard of hearing community by automatically converting spoken language to sign language.
            </p>
            <p className="text-lg text-gray-700 mb-6">
              Using advanced AI technologies including speech recognition, natural language processing, and 3D avatar animation, we transform standard videos into sign language videos with realistic signing avatars.
            </p>
            <p className="text-lg text-gray-700">
              Our mission is to break down communication barriers and make digital content universally accessible through innovative technology.
            </p>
          </div>
          
          <div className="bg-primary-50 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-4 text-primary-900">Our Impact</h2>
            <ul className="space-y-4">
              <li className="flex">
                <div className="mr-4 mt-1">
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                    <BarChart className="w-4 h-4 text-primary-700" />
                  </div>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">10,000+ Videos</h3>
                  <p className="text-gray-600">Converted to sign language</p>
                </div>
              </li>
              <li className="flex">
                <div className="mr-4 mt-1">
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                    <Globe className="w-4 h-4 text-primary-700" />
                  </div>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Global Reach</h3>
                  <p className="text-gray-600">Used in 30+ countries</p>
                </div>
              </li>
              <li className="flex">
                <div className="mr-4 mt-1">
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                    <HeartHandshake className="w-4 h-4 text-primary-700" />
                  </div>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Accessibility</h3>
                  <p className="text-gray-600">Making content accessible to 70M+ deaf users</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-6 text-gray-900">Our Technology</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
            <div className="flex">
              <div className="mr-6">
                <div className="w-12 h-12 bg-accent-100 rounded-full flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-accent-600" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Speech Recognition</h3>
                <p className="text-gray-700">
                  Using OpenAI's Whisper ASR technology, we accurately transcribe spoken content from videos, handling different accents, background noise, and technical vocabulary.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-6">
                <div className="w-12 h-12 bg-accent-100 rounded-full flex items-center justify-center">
                  <GitMerge className="w-6 h-6 text-accent-600" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900">NLP Processing</h3>
                <p className="text-gray-700">
                  Our natural language processing pipeline enhances transcription quality, adjusts content for sign language grammar, and preserves meaning for accurate translation.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-6">
                <div className="w-12 h-12 bg-accent-100 rounded-full flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-accent-600">
                    <path d="M6.5 11h11M14 16l4-4-4-4"></path>
                  </svg>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900">3D Avatar Generation</h3>
                <p className="text-gray-700">
                  MediaPipe and SignGAN technologies create fluid signing avatars that accurately represent hand shapes, movements, and non-manual features essential to sign languages.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-6">
                <div className="w-12 h-12 bg-accent-100 rounded-full flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-accent-600">
                    <path d="M12 2c-.8 0-1.5.7-1.5 1.5v5c0 .8.7 1.5 1.5 1.5s1.5-.7 1.5-1.5v-5c0-.8-.7-1.5-1.5-1.5z"></path>
                    <path d="M19.3 7.7c-.4-.4-1-.4-1.4 0-2.1 2.1-5.5 2.1-7.6 0-.4-.4-1-.4-1.4 0-.4.4-.4 1 0 1.4 1.2 1.2 2.8 1.9 4.5 1.9s3.3-.7 4.5-1.9c.4-.4.4-1 0-1.4z"></path>
                    <path d="M18 16.4c.2-.4.7-.5 1.1-.3.4.2.5.7.3 1.1-.7 1.5-1.9 2.7-3.4 3.4-.4.2-.9.1-1.1-.3-.2-.4-.1-.9.3-1.1 1.2-.5 2.1-1.5 2.8-2.8z"></path>
                    <path d="M7.6 16.4c.2.4.1.9-.3 1.1-.4.2-.9.1-1.1-.3-.7-1.5-1.9-2.7-3.4-3.4-.4-.2-.5-.7-.3-1.1.2-.4.7-.5 1.1-.3 1.2.5 2.1 1.5 2.8 2.8z"></path>
                  </svg>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Lip Synchronization</h3>
                <p className="text-gray-700">
                  Wav2Lip technology ensures our signing avatars have realistic lip movements synchronized with the signed content, enhancing clarity and natural appearance.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-6 text-gray-900">Why Choose SignSync</h2>
          
          <div className="bg-white shadow-lg rounded-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-3">
              {[
                {
                  title: 'High Accuracy',
                  description: 'State-of-the-art AI models ensure precise sign language translation',
                  color: 'bg-blue-500'
                },
                {
                  title: 'Customizable',
                  description: 'Tailor avatar appearance and signing style to your preferences',
                  color: 'bg-teal-500'
                },
                {
                  title: 'Fast Processing',
                  description: 'Convert videos quickly with our optimized processing pipeline',
                  color: 'bg-purple-500'
                }
              ].map((feature, index) => (
                <div key={index} className="relative">
                  <div className={`${feature.color} h-2`}></div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-3 text-gray-900">{feature.title}</h3>
                    <p className="text-gray-700">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        <section>
          <div className="bg-primary-900 text-white rounded-xl p-8 md:p-12">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-6">Ready to Make Your Videos Accessible?</h2>
              <p className="text-xl mb-8 text-primary-100">
                Start converting your videos to sign language today and reach a wider audience.
              </p>
              <Link 
                to="/convert" 
                className="px-8 py-4 bg-white text-primary-900 rounded-lg font-medium hover:bg-gray-100 transition-colors inline-flex items-center"
              >
                Get Started Now <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;
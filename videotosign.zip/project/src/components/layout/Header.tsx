import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Hand as Hands, Video, BookOpen, Info } from 'lucide-react';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { to: '/', label: 'Home', icon: <Hands className="w-5 h-5 mr-2" /> },
    { to: '/convert', label: 'Convert', icon: <Video className="w-5 h-5 mr-2" /> },
    { to: '/library', label: 'Library', icon: <BookOpen className="w-5 h-5 mr-2" /> },
    { to: '/about', label: 'About', icon: <Info className="w-5 h-5 mr-2" /> },
  ];

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link 
            to="/" 
            className="flex items-center space-x-2 text-2xl font-bold text-primary-900"
          >
            <Hands className="w-8 h-8" />
            <span>SignSync</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`flex items-center transition-colors duration-200 ${
                  location.pathname === link.to
                    ? 'text-primary-700 font-medium'
                    : 'text-gray-600 hover:text-primary-700'
                }`}
              >
                {link.icon}
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden p-2 text-gray-600 hover:text-primary-700 focus:outline-none"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <nav
        className={`md:hidden bg-white ${
          isOpen ? 'h-60' : 'h-0'
        } overflow-hidden transition-all duration-300 ease-in-out`}
      >
        <div className="container mx-auto px-4 py-2 space-y-4">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`flex items-center py-2 ${
                location.pathname === link.to
                  ? 'text-primary-700 font-medium'
                  : 'text-gray-600'
              }`}
            >
              {link.icon}
              {link.label}
            </Link>
          ))}
        </div>
      </nav>
    </header>
  );
};

export default Header;
import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, SkipBack, Settings } from 'lucide-react';
import { VideoPlayerProps } from '../../types';

const VideoPlayer: React.FC<VideoPlayerProps> = ({ 
  originalUrl, 
  convertedUrl, 
  showComparison = true 
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  
  const originalVideoRef = useRef<HTMLVideoElement>(null);
  const convertedVideoRef = useRef<HTMLVideoElement>(null);
  
  useEffect(() => {
    // Sync both videos when comparison mode is active
    if (showComparison && originalVideoRef.current && convertedVideoRef.current) {
      if (isPlaying) {
        originalVideoRef.current.play();
        convertedVideoRef.current.play();
      } else {
        originalVideoRef.current.pause();
        convertedVideoRef.current.pause();
      }
    }
  }, [isPlaying, showComparison]);
  
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };
  
  const handleMuteToggle = () => {
    setIsMuted(!isMuted);
    if (originalVideoRef.current) {
      originalVideoRef.current.muted = !isMuted;
    }
    if (convertedVideoRef.current) {
      convertedVideoRef.current.muted = !isMuted;
    }
  };
  
  const handleTimeUpdate = () => {
    if (originalVideoRef.current) {
      setCurrentTime(originalVideoRef.current.currentTime);
    }
  };
  
  const handleLoadedMetadata = () => {
    if (originalVideoRef.current) {
      setDuration(originalVideoRef.current.duration);
    }
  };
  
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    
    if (originalVideoRef.current) {
      originalVideoRef.current.currentTime = time;
    }
    
    if (showComparison && convertedVideoRef.current) {
      convertedVideoRef.current.currentTime = time;
    }
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="bg-black rounded-lg overflow-hidden">
      <div className={`relative ${showComparison ? 'flex' : 'block'}`}>
        <div className={showComparison ? 'w-1/2 border-r border-gray-800' : 'w-full'}>
          <video
            ref={originalVideoRef}
            src={originalUrl}
            className="w-full aspect-video object-contain"
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            muted={isMuted}
            playsInline
          />
          {showComparison && (
            <div className="absolute top-2 left-2 bg-black/60 text-white text-xs py-1 px-2 rounded">
              Original
            </div>
          )}
        </div>
        
        {showComparison && convertedUrl && (
          <div className="w-1/2">
            <video
              ref={convertedVideoRef}
              src={convertedUrl}
              className="w-full aspect-video object-contain"
              muted={isMuted}
              playsInline
            />
            <div className="absolute top-2 right-2 bg-black/60 text-white text-xs py-1 px-2 rounded">
              Sign Language
            </div>
          </div>
        )}
      </div>
      
      <div className="bg-gray-900 p-4">
        <div className="mb-2">
          <input
            type="range"
            min="0"
            max={duration || 100}
            value={currentTime}
            onChange={handleSeek}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={handlePlayPause}
              className="text-white hover:text-gray-300 transition-colors"
            >
              {isPlaying ? (
                <Pause className="w-5 h-5" />
              ) : (
                <Play className="w-5 h-5" />
              )}
            </button>
            
            <button
              onClick={() => {
                if (originalVideoRef.current) {
                  originalVideoRef.current.currentTime = 0;
                }
                if (convertedVideoRef.current) {
                  convertedVideoRef.current.currentTime = 0;
                }
              }}
              className="text-white hover:text-gray-300 transition-colors"
            >
              <SkipBack className="w-5 h-5" />
            </button>
            
            <button
              onClick={handleMuteToggle}
              className="text-white hover:text-gray-300 transition-colors"
            >
              {isMuted ? (
                <VolumeX className="w-5 h-5" />
              ) : (
                <Volume2 className="w-5 h-5" />
              )}
            </button>
            
            <span className="text-white text-sm">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="text-white hover:text-gray-300 transition-colors">
              <Settings className="w-5 h-5" />
            </button>
            
            <button className="text-white hover:text-gray-300 transition-colors">
              <Maximize className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
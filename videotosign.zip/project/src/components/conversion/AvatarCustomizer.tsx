import React from 'react';
import { AvatarSettings } from '../../types';
import { Check, ChevronDown, Play } from 'lucide-react';

interface AvatarCustomizerProps {
  settings: AvatarSettings;
  onSettingsChange: (settings: AvatarSettings) => void;
  onStartGeneration: () => void;
}

const AvatarCustomizer: React.FC<AvatarCustomizerProps> = ({ 
  settings, 
  onSettingsChange, 
  onStartGeneration 
}) => {
  const handleModelChange = (model: AvatarSettings['model']) => {
    onSettingsChange({ ...settings, model });
  };

  const handleGenderChange = (gender: AvatarSettings['gender']) => {
    onSettingsChange({ ...settings, gender });
  };

  const handleLanguageChange = (signLanguage: AvatarSettings['signLanguage']) => {
    onSettingsChange({ ...settings, signLanguage });
  };

  const handleSpeedChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onSettingsChange({ ...settings, speed: parseFloat(e.target.value) });
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6 text-gray-800">Customize Your Signing Avatar</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
        <div>
          <h3 className="text-lg font-medium mb-4 text-gray-800">Avatar Preview</h3>
          <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center overflow-hidden">
            <div className="w-full h-full bg-cover bg-center" style={{ backgroundImage: 'url(https://images.pexels.com/photos/7516363/pexels-photo-7516363.jpeg)' }}>
              <div className="w-full h-full flex items-center justify-center bg-black/40">
                <Play className="w-16 h-16 text-white opacity-80" />
              </div>
            </div>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500">
              Preview of your signing avatar with current settings.
              In the actual implementation, this would show a real-time 3D avatar preview.
            </p>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-medium mb-4 text-gray-800">Avatar Settings</h3>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Avatar Model
              </label>
              <div className="grid grid-cols-3 gap-4">
                {['default', 'realistic', 'cartoon'].map((model) => (
                  <button
                    key={model}
                    onClick={() => handleModelChange(model as AvatarSettings['model'])}
                    className={`px-4 py-3 rounded-lg border ${
                      settings.model === model
                        ? 'bg-primary-50 border-primary-500 text-primary-700'
                        : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                    } text-sm font-medium transition-colors`}
                  >
                    {model.charAt(0).toUpperCase() + model.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Avatar Gender
              </label>
              <div className="grid grid-cols-3 gap-4">
                {['male', 'female', 'neutral'].map((gender) => (
                  <button
                    key={gender}
                    onClick={() => handleGenderChange(gender as AvatarSettings['gender'])}
                    className={`px-4 py-3 rounded-lg border ${
                      settings.gender === gender
                        ? 'bg-primary-50 border-primary-500 text-primary-700'
                        : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                    } text-sm font-medium transition-colors`}
                  >
                    {gender.charAt(0).toUpperCase() + gender.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sign Language
              </label>
              <div className="relative">
                <select
                  value={settings.signLanguage}
                  onChange={(e) => handleLanguageChange(e.target.value as AvatarSettings['signLanguage'])}
                  className="block w-full rounded-lg border border-gray-300 py-3 px-4 text-gray-700 appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="asl">American Sign Language (ASL)</option>
                  <option value="bsl">British Sign Language (BSL)</option>
                  <option value="auslan">Australian Sign Language (Auslan)</option>
                </select>
                <ChevronDown className="absolute right-3 top-3.5 w-5 h-5 text-gray-400 pointer-events-none" />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Signing Speed: {settings.speed.toFixed(1)}x
              </label>
              <input
                type="range"
                min="0.5"
                max="1.5"
                step="0.1"
                value={settings.speed}
                onChange={handleSpeedChange}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Slower (0.5x)</span>
                <span>Normal (1.0x)</span>
                <span>Faster (1.5x)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button
          onClick={onStartGeneration}
          className="px-6 py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
        >
          Generate Sign Language Video
        </button>
      </div>
    </div>
  );
};

export default AvatarCustomizer;
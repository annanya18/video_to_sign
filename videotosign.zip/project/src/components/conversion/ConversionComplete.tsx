import React, { useState } from 'react';
import { VideoData } from '../../types';
import { Download, Share2, Code, Check, Copy } from 'lucide-react';
import VideoPlayer from '../shared/VideoPlayer';
import toast from 'react-hot-toast';

interface ConversionCompleteProps {
  video: VideoData;
}

const ConversionComplete: React.FC<ConversionCompleteProps> = ({ video }) => {
  const [showComparison, setShowComparison] = useState(true);
  const [copied, setCopied] = useState(false);

  const handleDownload = () => {
    // In a real implementation, this would initiate a download of the processed video
    toast.success('Download started!');
  };

  const handleShare = () => {
    // In a real implementation, this would open a share dialog
    toast.success('Share dialog opened!');
  };

  const handleCopyEmbed = () => {
    // In a real implementation, this would copy embed code to clipboard
    navigator.clipboard.writeText('<iframe src="https://signsync.ai/embed/video123" width="640" height="360" frameborder="0" allowfullscreen></iframe>');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('Embed code copied to clipboard!');
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6 text-gray-800">Conversion Complete!</h2>
      
      <div className="mb-6">
        <VideoPlayer 
          originalUrl={video.originalUrl} 
          convertedUrl={video.convertedUrl} 
          showComparison={showComparison}
        />
        
        <div className="mt-4 flex items-center">
          <label className="flex items-center cursor-pointer">
            <div className="relative">
              <input
                type="checkbox"
                className="sr-only"
                checked={showComparison}
                onChange={() => setShowComparison(!showComparison)}
              />
              <div className={`block w-14 h-8 rounded-full transition ${showComparison ? 'bg-primary-600' : 'bg-gray-300'}`}></div>
              <div className={`absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition transform ${showComparison ? 'translate-x-6' : ''}`}></div>
            </div>
            <span className="ml-3 text-gray-700 font-medium">
              Show side-by-side comparison
            </span>
          </label>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <button
          onClick={handleDownload}
          className="flex items-center justify-center py-3 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <Download className="w-5 h-5 mr-2" />
          Download Video
        </button>
        <button
          onClick={handleShare}
          className="flex items-center justify-center py-3 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <Share2 className="w-5 h-5 mr-2" />
          Share Video
        </button>
        <button
          onClick={handleCopyEmbed}
          className="flex items-center justify-center py-3 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
        >
          {copied ? (
            <>
              <Check className="w-5 h-5 mr-2 text-green-600" />
              Copied!
            </>
          ) : (
            <>
              <Code className="w-5 h-5 mr-2" />
              Copy Embed Code
            </>
          )}
        </button>
      </div>
      
      <div className="bg-gray-50 rounded-lg p-6 border">
        <h3 className="font-semibold text-gray-800 mb-3">Processing Summary</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-gray-600">Video Title:</span>
            <span className="font-medium text-gray-800">{video.title}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Duration:</span>
            <span className="font-medium text-gray-800">
              {Math.floor(video.duration / 60)}:{(video.duration % 60).toString().padStart(2, '0')}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Sign Language:</span>
            <span className="font-medium text-gray-800">American Sign Language (ASL)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Avatar Model:</span>
            <span className="font-medium text-gray-800">Realistic</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Processing Time:</span>
            <span className="font-medium text-gray-800">3 minutes 42 seconds</span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 text-center">
        <h3 className="font-semibold text-gray-800 mb-3">Need to convert another video?</h3>
        <a href="/convert" className="inline-block px-6 py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors">
          Start New Conversion
        </a>
      </div>
    </div>
  );
};

export default ConversionComplete;
import React, { useState, useRef } from 'react';
import { Upload, X, FileVideo } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { VideoUploadProps } from '../../types';

const VideoUploader: React.FC<VideoUploadProps> = ({ onUploadComplete }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.type.startsWith('video/')) {
        handleFileSelect(droppedFile);
      }
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileSelect(e.target.files[0]);
    }
  };

  const handleFileSelect = (selectedFile: File) => {
    setFile(selectedFile);
  };

  const handleRemoveFile = () => {
    setFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleUpload = () => {
    if (!file) return;
    
    setUploading(true);
    
    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      setUploadProgress(progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        
        // Create a URL for the uploaded video
        const url = URL.createObjectURL(file);
        
        // Create mock video data for the uploaded file
        const videoData = {
          id: uuidv4(),
          title: file.name.replace(/\.[^/.]+$/, ''),
          originalUrl: url,
          duration: 120, // Mock duration in seconds
          uploadDate: new Date(),
          progress: 0,
          status: 'uploading' as const,
        };
        
        // Call the complete handler after a short delay to simulate processing
        setTimeout(() => {
          onUploadComplete(videoData);
          setUploading(false);
          setFile(null);
          setUploadProgress(0);
        }, 500);
      }
    }, 100);
  };

  return (
    <div className="w-full">
      <h2 className="text-2xl font-semibold mb-6 text-gray-800">Upload Your Video</h2>
      
      {!file ? (
        <div
          className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors ${
            isDragging 
              ? 'border-primary-500 bg-primary-50' 
              : 'border-gray-300 hover:border-primary-400 hover:bg-gray-50'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-medium mb-2 text-gray-700">
            Drag and drop your video
          </h3>
          <p className="text-gray-500 mb-4">
            Or click to browse your files
          </p>
          <p className="text-sm text-gray-400">
            Supported formats: MP4, MOV, AVI, WebM (max 500MB)
          </p>
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept="video/*"
            onChange={handleFileInputChange}
          />
        </div>
      ) : (
        <div className="border rounded-lg p-6">
          <div className="flex items-center mb-4">
            <FileVideo className="w-8 h-8 text-primary-600 mr-3" />
            <div className="flex-1">
              <p className="font-medium truncate">{file.name}</p>
              <p className="text-sm text-gray-500">
                {(file.size / (1024 * 1024)).toFixed(2)} MB
              </p>
            </div>
            <button 
              onClick={handleRemoveFile}
              className="p-2 text-gray-500 hover:text-gray-700"
              disabled={uploading}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          {uploading && (
            <div className="mb-4">
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary-600 transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-600 mt-1 text-right">
                {uploadProgress}% uploaded
              </p>
            </div>
          )}
          
          <button
            onClick={handleUpload}
            disabled={uploading}
            className={`w-full py-3 rounded-lg font-medium transition-colors ${
              uploading
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-primary-600 text-white hover:bg-primary-700'
            }`}
          >
            {uploading ? 'Uploading...' : 'Start Upload'}
          </button>
        </div>
      )}

      <div className="mt-8">
        <h3 className="text-lg font-medium mb-4 text-gray-800">Tips for Best Results</h3>
        <ul className="space-y-2 text-gray-600">
          <li className="flex items-start">
            <span className="inline-block w-4 h-4 rounded-full bg-primary-600 mt-1 mr-2"></span>
            Use videos with clear audio and minimal background noise
          </li>
          <li className="flex items-start">
            <span className="inline-block w-4 h-4 rounded-full bg-primary-600 mt-1 mr-2"></span>
            Ensure speakers are using natural pace and clear pronunciation
          </li>
          <li className="flex items-start">
            <span className="inline-block w-4 h-4 rounded-full bg-primary-600 mt-1 mr-2"></span>
            Shorter videos (under 10 minutes) process more quickly
          </li>
          <li className="flex items-start">
            <span className="inline-block w-4 h-4 rounded-full bg-primary-600 mt-1 mr-2"></span>
            Higher resolution videos will result in clearer signing avatars
          </li>
        </ul>
      </div>
    </div>
  );
};

export default VideoUploader;